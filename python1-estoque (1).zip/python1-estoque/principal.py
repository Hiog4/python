#pip install Flask==1.1.4
#pip install markupsafe==2.0.1

from flask import Flask, render_template, request, url_for, redirect
from produto import Produto

app = Flask(__name__)
app.secret_key = 'softgraf'

lista = []
p1 = Produto('TV LG 50"', 2999, 10, id=1)
p2 = Produto('Smartphone LG', 1999, 20, id=2)
p3 = Produto('Computador i5', 5999, 5, id=3)

lista.append(p1)
lista.append(p2)
lista.append(p3)

@app.route('/')
def index():
    return render_template('relatorio.html', titulo='relatório de estoque', produtos=lista)

@app.route('/cadastrar')
def cadastrar():
    return render_template('cadastrar.html', titulo='Cadastro Novo Produto')

@app.route('/salvar', methods=['POST'])
def salvar():
    id = request.form['id']
    descricao = request.form['descricao']
    preco = request.form['preco']
    quantidade = request.form['quantidade']
    produto = Produto(descricao, preco, quantidade, id)
    lista.append(produto)
    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True)